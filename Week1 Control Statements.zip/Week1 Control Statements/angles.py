"""Read three angles of triangles and determine their types(Right triangle, Obtuse triangle, Acute triangle)."""

a= int(input("enter first angle"))
b= int(input("enter second angle"))
c= int(input("enter third angle"))
if a+b+c==180 and a>0 and b>0 and c>0:
    if a== 90 or b==90 or c==90:
        print("right triangle")
    elif a<90 or b<90 or c<90:
        print("acute triangle")
    else:
        print("obtuse triangle")
else:
    print("not valid")