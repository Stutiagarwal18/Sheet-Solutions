"""wap to input three numbers and print the minimum among them"""

n1 = int(input("enter first number"))
n2 = int(input("enter second number"))
n3 = int(input("enter third number"))
minimum = min(n1,n2,n3)
print("minimum number is",minimum)