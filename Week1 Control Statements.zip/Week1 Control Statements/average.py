"""give 5 no. a,b,c,d,e as input. print the avg of these 5 no. """

a = int(input("enter first number"))
b= int(input("enter second number"))
c= int(input("enter third number"))
d = int(input("enter fourth number"))
e = int(input("enter fifth number"))

avg = (a+b+c+d+e)/5
print("average is",avg)