"""WAP to check whether a person is eligible to vote or not. """

age= int(input("enter the age"))
if age>=18:
    print("eligible to vote")
else:
    print("not eligible")