"""Write a program to print all even numbers from 1 to N, where you have to take N as input 
from the user."""

N= int(input("enter the number:"))
i= 2
while i<=N:
    print(i)
    i +=2
print()